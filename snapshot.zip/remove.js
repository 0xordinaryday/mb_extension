/* Change notes
removes div added by recent.js (i.e. the sidebar)
*/

$(function() {
    // remove container
    document.getElementById('container').style.visibility = "hidden";
});