/* Change notes
redraws div added by recent.js (i.e. the sidebar)
*/

$(function() {
    // display container
    document.getElementById('container').style.visibility = "visible";
});
    